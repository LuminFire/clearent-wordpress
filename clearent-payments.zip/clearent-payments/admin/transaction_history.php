<div class="postbox">
    <h3>Transaction History</h3>
    <?php

    $options = get_option("clearent_opts");

    $payment_data = array();
    if ($options['environment'] == "sandbox") {
        $mode = "sandbox";
    } else {
        $mode = "production";
    }

    global $wpdb;
    $table_name = $wpdb->prefix . "clearent_transaction";
    $query = "SELECT *
             FROM $table_name
             WHERE environment = '$mode'
             AND date_added > NOW() - INTERVAL 90 DAY
             ORDER BY date_added DESC";
    $recordset = $wpdb->get_results($query);
    if ($mode == "sandbox") {
        echo('<p class="warning">');
    } else {
        echo('<p>');
    }
    echo('Application is in ' . $mode . ' mode. Viewing transactions for ' . $mode . '.</p>');
    if (empty($recordset)) {
        echo('There are no successful transctions to display.');
    } else {
        echo('<p>Below is a list of successful transactions in the last 90 days.  Most recent transactions are listed first.</p>');
        echo('<table class="trans_history">');
        echo('  <tr>');
        echo('    <th>order id</th>');
        echo('    <th>summary</th>');
        echo('    <th>email</th>');
        echo('    <th>billing address</th>');
        echo('    <th>shipping address</th>');
        echo('    <th>date</th>');
        echo('</tr>');

        foreach ($recordset as $r) {
            echo('  <tr onclick="showDetails(\'' . $r->transaction_id . '\')">');
            echo('    <td>' . $r->order_id . '</td>');
            echo('    <td><span class="label">Result:</span>' . $r->result . '<br>'
                . '<span class="label">Exchange ID:</span>' . $r->exchange_id . '<br>'
                . '<span class="label">Transaction ID:</span>' . $r->transaction_id . '<br>'
                . '<span class="label">Authorization Code:</span>' . $r->authorization_code . '<br>'
                . '<span class="label">Amount:</span>' . $r->amount . '<br>'
                . '<span class="label">Card:</span>' . $r->card . '<br>'
                . '<span class="label">Expiration Date:</span>' . $r->exp_date
                . '</td>');
            echo('    <td>' . $r->email_address . '</td>');
            echo('    <td>' . $r->billing_firstname . ' '
                . $r->billing_lastname . '<br>'
                . $r->billing_company . '<br>'
                . $r->billing_street . '<br>'
                . $r->billing_street2 . '<br>'
                . $r->billing_city . ', ' . $r->billing_state . '&nbsp;&nbsp;' . $r->billing_zip . '<br>'
                . $r->billing_country . '<br>'
                . $r->billing_phone . '</td>');
            echo('    <td>' . $r->shipping_firstname . ' '
                . $r->shipping_lastname . '<br>'
                . $r->shipping_company . '<br>'
                . $r->shipping_street . '<br>'
                . $r->shipping_street2 . '<br>'
                . $r->shipping_city . ', ' . $r->shipping_state . '&nbsp;&nbsp;' . $r->shipping_zip . '<br>'
                . $r->shipping_country . '<br>'
                . $r->shipping_phone . '</td>');
            echo('    <td><span class="label">created:</span>' . $r->date_added . '<br>'
                . '<span class="label">modified:</span>' . $r->date_modified . '</td>');
            echo('</tr>');
        }

        echo('</table>');

        echo('<div style="display:none;">');
        echo('    <div id="dialog" title="Transaction Detail"></div>');
        echo('</div>');

    }
    ?>
</div>
