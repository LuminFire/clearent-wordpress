<?php

class transactions {

    public function transaction_detail() {

        $id = $_REQUEST["id"];

        global $wpdb;
        $table_name = $wpdb->prefix . "clearent_transaction";
        $query = "SELECT *
                  FROM $table_name
                  WHERE transaction_id = $id";
        $recordset = $wpdb->get_results($query);
        if (empty($recordset)) {
            // this shouldn't every happen - if we log the transaction, we have an ID
            echo('Transaction detail not available.');
        } else {
            echo('<table class="trans_detail">');
            foreach ($recordset as $r) {
                echo('<tr><td><span class="label">Order ID</span></td><td>' . $r->order_id . '</td><td><span class="label">Invoice</span></td><td>' . $r->invoice . '</td></tr>');
                echo('<tr><td><span class="label">Customer ID</span></td><td>' . $r->customer_id . '</td><td><span class="label">Purchase Order</span></td><td>' . $r->purchase_order . '</td></tr>');
                echo('<tr><td><span class="label">Transaction Type</span></td><td>' . $r->transaction_type . '</td><td><span class="label">Amount</span></td><td>' . $r->amount . '</td></tr>');
                echo('<tr><td><span class="label">Card</span></td><td>' . $r->card . '</td><td><span class="label">Card Expire Date</span></td><td>' . $r->exp_date . '</td></tr>');
                echo('<tr><td><span class="label">Result</span></td><td>' . $r->result . '</td><td><span class="label">Result Code</span></td><td>' . $r->result_code . '</td></tr>');
                echo('<tr><td><span class="label">Transaction ID</span></td><td>' . $r->transaction_id . '</td><td><span class="label">Exchange ID</span></td><td>' . $r->exchange_id . '</td></tr>');
                echo('<tr><td><span class="label">Authorization Code</span></td><td>' . $r->authorization_code . '</td><td><span class="label">Email Address</span></td><td>' . $r->email_address . '</td></tr>');
                echo('<tr><td><span class="label">Description</span></td><td>' . $r->description . '</td><td><span class="label">Comments</span></td><td>' . $r->comments . '</td></tr>');
                echo('<tr><td><span class="label">Billing Address</span></td><td>'
                    . $r->billing_firstname . ' '
                    . $r->billing_lastname . '<br>'
                    . $r->billing_company . '<br>'
                    . $r->billing_street . '<br>'
                    . $r->billing_street2 . '<br>'
                    . $r->billing_city . ', ' . $r->billing_state . '&nbsp;&nbsp;' . $r->billing_zip . '<br>'
                    . $r->billing_country . '<br>'
                    . $r->billing_phone
                    . '</td><td><span class="label">Shipping Address</span></td><td>'
                    . $r->shipping_firstname . ' '
                    . $r->shipping_lastname . '<br>'
                    . $r->shipping_company . '<br>'
                    . $r->shipping_street . '<br>'
                    . $r->shipping_street2 . '<br>'
                    . $r->shipping_city . ', ' . $r->shipping_state . '&nbsp;&nbsp;' . $r->shipping_zip . '<br>'
                    . $r->shipping_country . '<br>'
                    . $r->shipping_phone
                    . '</td>');
                echo('<tr><td><span class="label">Date Added</span></td><td>' . $r->date_added . '</td><td><span class="label">Date Modified</span></td><td>' . $r->date_modified . '</td></tr>');
                echo('<tr><td><span class="label">Client IP</span></td><td>' . $r->client_ip . '</td><td><span class="label">User Agent</span></td><td>' . $r->user_agent . '</td></tr>');
            }
            echo('</table>');
        }

    }

}