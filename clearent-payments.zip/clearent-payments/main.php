<?php

/**
 * Plugin Name: Clearent Payments
 * Plugin URI: https://wordpress.org/plugins/clearent-payments/
 * Description: Quickly and easily add secure, PCI Compliant, payment to your WordPress site. This plugin is maintained directly by Clearent, a leader in payments.
 * Version: 1.3
 * Author: Clearent, LLC.
 * Author URI: http://clearent.github.io/wordpress/
 */
define('WP_DEBUG', true);

class wp_clearent {

    const SANDBOX_HPP_URL = "https://hpp-sb.clearent.net/js/clearent.js";
    const PRODUCTION_HPP_URL = "https://hpp.clearent.net/js/clearent.js";

    const SANDBOX_API_URL = "https://gateway-sb.clearent.net/rest/v2/transactions";
    const PRODUCTION_API_URL = "https://gateway.clearent.net/rest/v2/transactions";


    protected $option_name = 'clearent_opts';

    public function __construct() {
        require_once('clearent_util.php');
        require_once('clearent_wp_util.php');
        $this->clearent_util = new clearent_util();
        $this->clearent_wp_util = new clearent_wp_util();

        // seession management needed for this plugin
        add_action('init', array($this, 'myStartSession'));                                 // Used to create a session for storing tranaaction data
        add_action('wp_logout', array($this, 'myEndSession'));                              // Used to destroy session after logout
        add_action('wp_login', array($this, 'myEndSession'));                               // Used to destroy session after login
        // admin hooks
        add_action('admin_init', array($this, 'registerSettings'));                         // Used for registering settings
        add_action('admin_menu', array($this, 'admin_menu'));                               // Creates admin menu page and conditionally loads scripts and styles on admin page
        add_action('admin_post_transaction', array($this, 'validate'));                     // hook for transaction calls - logged in user
        add_action('admin_post_nopriv_transaction', array($this, 'validate'));              // hook for transaction calls - non-logged in user
        add_action('admin_post_transaction_detail', array($this, 'transaction_detail'));    // hook for transaction calls - logged in user
        add_filter('plugin_action_links', array($this, 'add_action_plugin'), 10, 5);      // add settings link to plugin
        // shortcode hooks
        add_action('admin_post_nopriv_transaction_detail', array($this, 'transaction_detail'));     // hook for transaction calls - non-logged in user
        add_shortcode('clearent_pay_form', array($this, 'clearent_pay_form'));              // builds content for embedded form
        add_shortcode('clearent_pay_button', array($this, 'clearent_pay_button'));          // builds content for HPP button
        register_activation_hook(__FILE__, array($this, 'activate'));                       // Activate plugin
        register_activation_hook(__FILE__, array($this, 'install_db'));                     // Create database tables


    }

    // attempt to create a session
    function myStartSession() {
        if (!session_id()) {
            session_start();
        }
    }

    function myEndSession() {
        session_destroy();
    }

    // Register Plugin settings array
    public function registerSettings() {
        register_setting('clearent_option_group', $this->option_name, array($this, 'validate_options'));
    }

    function add_action_plugin($actions, $plugin_file) {
        static $plugin;

        if (!isset($plugin))
            $plugin = plugin_basename(__FILE__);
        if ($plugin == $plugin_file) {

            $settings = array('settings' => '<a href="options-general.php?page=clearent_option_group">' . __('Settings', 'General') . '</a>');
            //$site_link = array('support' => '<a href="http://clearent.github.io/wordpress/" target="_blank">Support</a>');

            $actions = array_merge($settings, $actions);
            //$actions = array_merge($site_link, $actions);

        }

        return $actions;
    }

    // Initialize admin page
    public function admin_menu() {
        // add_options_page( $page_title, $menu_title, $capability, $menu_slug, $function);
        $wp_clearent_page = add_options_page('Clearent Payments', 'Clearent Payments', 'manage_options', 'clearent_option_group', array($this, 'settingsPage'));
        add_action('admin_print_scripts-' . $wp_clearent_page, array($this, 'admin_scripts'));  // Load our admin page scripts (our page only)
        add_action('admin_print_styles-' . $wp_clearent_page, array($this, 'wp_clearent_admin_print_styles'));    // Load our admin page stylesheet (our page only)

    }

    public function validate_options($input) {

        $valid = array();
        $valid['environment'] = isset($input['environment']) ? $input['environment'] : 'sandbox';
        $valid['success_url'] = isset($input['success_url']) ? $input['success_url'] : '-1';
        $valid['sb_api_key'] = isset($input['sb_api_key']) ? $input['sb_api_key'] : '';
        $valid['prod_api_key'] = isset($input['prod_api_key']) ? $input['prod_api_key'] : '';
        $valid['enable_debug'] = isset($input['enable_debug']) ? $input['enable_debug'] : '';

        return $valid;
    }

    public function admin_scripts() {
        wp_enqueue_script('admin.js', plugins_url('/js/admin.js', __FILE__));
        wp_enqueue_script('loading.js', plugins_url('/js/loading.js', __FILE__));
    }

    public function wp_clearent_admin_print_styles() {
        wp_enqueue_style('admin.css', plugins_url('/css/admin.css', __FILE__));
        wp_enqueue_style('loading.css', plugins_url('/css/loading.css', __FILE__));
    }

    // Generate admin options page
    /**
     *
     */
    public function settingsPage() {

        $options_opts = get_option($this->option_name);

        // set up directories
        $plugins_url = plugins_url();
        $get_admin_url = get_admin_url();

        //$trans_path = $plugins_url . "/clearent-payments/clearent/transaction.php";
        //$js_path = $plugins_url . "/clearent-payments/js/";
        $css_path = $plugins_url . "/clearent-payments/css/";
        //$image_path = $plugins_url . "/clearent-payments/image/";

        $trans_url = $get_admin_url . 'admin-post.php';

        wp_enqueue_script('jquery-ui-dialog');
        wp_enqueue_style('jquery-ui', $css_path . 'jquery-ui.min.css');

        ?>
        <div class="wrap">
            <h2><?php echo('Clearent Payments'); ?></h2>

            <?php
            $active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'api_keys';
            ?>
            <script type="text/javascript">
                var trans_url = "<?php echo($trans_url) ?>";
            </script>
            <h2 class="nav-tab-wrapper">
                <a href="?page=clearent_option_group&tab=plugin_settings"
                   class="nav-tab <?php echo $active_tab == 'plugin_settings' ? 'nav-tab-active' : ''; ?>">Plugin
                    Settings</a>
                <a href="?page=clearent_option_group&tab=transaction_history"
                   class="nav-tab <?php echo $active_tab == 'transaction_history' ? 'nav-tab-active' : ''; ?>">Transaction
                    History</a>
                <a href="?page=clearent_option_group&tab=active_forms"
                   class="nav-tab <?php echo $active_tab == 'active_forms' ? 'nav-tab-active' : ''; ?>">Pages Using
                    Plugin</a>
                <a href="?page=clearent_option_group&tab=debug_log"
                   class="nav-tab <?php echo $active_tab == 'debug_log' ? 'nav-tab-active' : ''; ?>">Debug Log</a>
            </h2>


            <form name="clearent_clear_log" method="post"
                  action="<?php echo plugin_dir_url(__FILE__) ?>clearent_clear_log.php">
                <input type="hidden" name="confirm" value="true"/>
                <input type="hidden" name="plugin_dir_path" value="<?php echo plugin_dir_path(__FILE__) ?>"/>
                <input type="hidden" name="redirect_url" value="<?php echo get_admin_url() ?>"/>
            </form>

            <form method="post" action="options.php">

                <?php
                if ($active_tab == 'debug_log') {
                    // Debug Log Tab
                    ?>

                    <script>
                        plugin_path = "<?php echo plugin_dir_url( __FILE__ ) ?>";
                    </script>
                    <div id="dialogConfirm" title="Confirmation Required">
                        <p>This will clear the debug log. <br>This action cannot be undone.</p>
                    </div>

                    <div class="postbox">

                        <input type="button" value="Clear Debug Log File" onclick="showConfirmation();"/>
                        <br><br>

                        <div class="logbox">
                            <?php

                            $logfile = plugin_dir_path(__FILE__) . "log/debug.log";
                            $content = file_get_contents($logfile);

                            echo "[" . $logfile . "]";
                            echo "<br>";

                            $content = apply_filters('the_content', $content);
                            echo $content;

                            ?>
                        </div>
                    </div>


                <?php
                } elseif ($active_tab == 'transaction_history') {
                // Transaction History Tab
                ?>
                    <div class="postbox">
                        <h3>Transaction History</h3>
                        <?php

                        global $wpdb;
                        $table_name = $wpdb->prefix . "clearent_transaction";
                        $query = "SELECT *
                              FROM $table_name
                              WHERE date_added > NOW() - INTERVAL 90 DAY
                              ORDER BY date_added DESC";
                        $recordset = $wpdb->get_results($query);
                        if (empty($recordset)) {
                            echo('There are no successful transctions to display.');
                        } else {
                            echo('<p>Below is a list of successful transactions in the last 90 days.  Most recent transactions are listed first.</p>');
                            echo('<table class="trans_history">');
                            echo('  <tr>');
                            echo('    <th>order id</th>');
                            echo('    <th>summary</th>');
                            echo('    <th>email</th>');
                            echo('    <th>billing address</th>');
                            echo('    <th>shipping address</th>');
                            echo('    <th>date</th>');
                            echo('</tr>');

                            foreach ($recordset as $r) {
                                echo('  <tr onclick="showDetails(\'' . $r->transaction_id . '\')">');
                                echo('    <td>' . $r->order_id . '</td>');
                                echo('    <td><span class="label">Result:</span>' . $r->result . '<br>'
                                    . '<span class="label">Exchange ID:</span>' . $r->exchange_id . '<br>'
                                    . '<span class="label">Transaction ID:</span>' . $r->transaction_id . '<br>'
                                    . '<span class="label">Authorization Code:</span>' . $r->authorization_code . '<br>'
                                    . '<span class="label">Amount:</span>' . $r->amount . '<br>'
                                    . '<span class="label">Card:</span>' . $r->card . '<br>'
                                    . '<span class="label">Expiration Date:</span>' . $r->exp_date
                                    . '</td>');
                                echo('    <td>' . $r->email_address . '</td>');
                                echo('    <td>' . $r->billing_firstname . ' '
                                    . $r->billing_lastname . '<br>'
                                    . $r->billing_company . '<br>'
                                    . $r->billing_street . '<br>'
                                    . $r->billing_street2 . '<br>'
                                    . $r->billing_city . ', ' . $r->billing_state . '&nbsp;&nbsp;' . $r->billing_zip . '<br>'
                                    . $r->billing_country . '<br>'
                                    . $r->billing_phone . '</td>');
                                echo('    <td>' . $r->shipping_firstname . ' '
                                    . $r->shipping_lastname . '<br>'
                                    . $r->shipping_company . '<br>'
                                    . $r->shipping_street . '<br>'
                                    . $r->shipping_street2 . '<br>'
                                    . $r->shipping_city . ', ' . $r->shipping_state . '&nbsp;&nbsp;' . $r->shipping_zip . '<br>'
                                    . $r->shipping_country . '<br>'
                                    . $r->shipping_phone . '</td>');
                                echo('    <td><span class="label">created:</span>' . $r->date_added . '<br>'
                                    . '<span class="label">modified:</span>' . $r->date_modified . '</td>');
                                echo('</tr>');
                            }

                            echo('</table>');

                            echo('<div style="display:none;">');
                            echo('    <div id="dialog" title="Transaction Detail"></div>');
                            echo('</div>');

                        }
                        ?>
                    </div>
                <?php
                } elseif ($active_tab == 'active_forms') {
                // Pay Now Buttons Tab
                ?>
                    <div class="postbox">
                        <h3>Active Pages Using Clearent Payments Plugin Shortcode</h3>

                        <p>Below is a list of all pages that use the Clearent Payments plugin shortcode (links open in
                            new window).</p>
                        <?php
                        // Display pages using the shortcode
                        $args = array('order' => 'ASC', 's' => '[clearent_pay_form ');
                        $pages = new WP_Query($args);
                        if ($pages->have_posts()) {
                            echo '<ul>';
                            while ($pages->have_posts()) {
                                $pages->the_post();
                                ?>
                                <li><a target="_blank" href="<?php the_permalink() ?>"><?php the_title(); ?></a>
                                </li><?php
                            }
                            echo '</ul>';
                        } else {
                            echo('There are no pages that use the Clearent Payments plugin shortcode.');
                        }
                        wp_reset_postdata();
                        ?>
                    </div>
                <?php
                } else {
                // Settings tab
                ?>
                    <div class="postbox">
                        <?php settings_fields('clearent_option_group'); ?>

                        <h3>Environment</h3>

                        <p>By default, the Clearent Payments plugin will perform all transactions against the production
                            environment.
                            The plugin may be switched to sandbox environment for testing purposes.
                        </p>
                        <table class="form-table">
                            <tr valign="top">
                                <th scope="row">Environment:</th>
                                <td>
                                    <input id="environment_sandbox" type="radio"
                                           name="<?php echo $this->option_name ?>[environment]"
                                           value="sandbox" <?php checked('sandbox', $options_opts['environment']); ?> />
                                    <label for="environment_sandbox">Sandbox</label>
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <input id="environment_live" type="radio"
                                           name="<?php echo $this->option_name ?>[environment]"
                                           value="production" <?php checked('production', $options_opts['environment']); ?> />
                                    <label for="environment_live">Production</label>
                                </td>
                            </tr>
                        </table>

                        <h3>Success URL</h3>

                        <p>Enter a url for successful transactions (a success page). If no url
                            is specified (blank), the user will be redirected to the home page.
                        </p>
                        <table class="form-table">
                            <tr valign="top">
                                <th scope="row"><label for="success_url">Success URL:</label></th>
                                <td>
                                    <?php
                                    $args = array(
                                        'depth' => 0,
                                        'child_of' => 0,
                                        'selected' => $options_opts['success_url'],
                                        'echo' => 1,
                                        'name' => 'clearent_opts[success_url]',
                                        'id' => 'success_url', // string
                                        'class' => 'large', // string
                                        'show_option_none' => 'Homepage', // string
                                        'show_option_no_change' => null, // string
                                        'option_none_value' => '-1', // string
                                    );
                                    wp_dropdown_pages($args);
                                    ?>
                                </td>
                            </tr>
                        </table>

                        <h3>API Keys</h3>

                        <p>Contact <a target="_blank" href="http://developer.clearent.com/getting-started/">Clearent</a>
                            to obtain
                            API keys for Sandbox (testing) and Production. A Clearent Sandbox Account and a Clearent
                            Production
                            Account will have different API keys.
                        </p>
                        <table class="form-table">
                            <tr valign="top">
                                <th scope="row"><label for="sb_api_key">Sandbox API Key</label></th>
                                <td><input type="text" class="large" id="sb_api_key"
                                           name="<?php echo $this->option_name ?>[sb_api_key]"
                                           value="<?php echo $options_opts['sb_api_key']; ?>"/></td>
                            </tr>
                            <tr valign="top">
                                <th scope="row"><label for="prod_api_key">Production API Key</label></th>
                                <td><input type="text" class="large" id="prod_api_key"
                                           name="<?php echo $this->option_name ?>[prod_api_key]"
                                           value="<?php echo $options_opts['prod_api_key']; ?>"/></td>
                            </tr>
                        </table>

                        <h3>Debug Logging</h3>

                        <p>Enable debug to help diagnose issues or if instructed by Clearent support. Debug mode can
                            quickly fill up php logs and should be disabled unless debugging a specific issue.</p>
                        <table class="form-table">
                            <tr valign="top">
                                <th scope="row">Enable Debug Logging?</th>
                                <td>
                                    <input id="enable_debug_disabled" type="radio"
                                           name="<?php echo $this->option_name ?>[enable_debug]"
                                           value="disabled" <?php checked('disabled', $options_opts['enable_debug']); ?> />
                                    <label for="enable_debug_disabled">Disabled</label>
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <input id="enable_debug_enabled" type="radio"
                                           name="<?php echo $this->option_name ?>[enable_debug]"
                                           value="enabled" <?php checked('enabled', $options_opts['enable_debug']); ?> />
                                    <label for="enable_debug_enabled">Enabled</label>


                                </td>
                            </tr>
                        </table>


                    </div>
                    <?php
                }
                ?>
                <p class="submit">
                    <input type="submit" class="button-primary" value="Save Changes"/>
                </p>
            </form>


        </div> <!-- End wrap -->
        <?php

    }

    public function transaction_detail() {

        $id = $_REQUEST["id"];

        global $wpdb;
        $table_name = $wpdb->prefix . "clearent_transaction";
        $query = "SELECT *
                  FROM $table_name
                  WHERE transaction_id = $id";
        $recordset = $wpdb->get_results($query);
        if (empty($recordset)) {
            // this shouldn't every happen - if we log the transaction, we have an ID
            echo('Transaction detail not available.');
        } else {
            echo('<table class="trans_detail">');
            foreach ($recordset as $r) {
                echo('<tr><td><span class="label">Order ID</span></td><td>' . $r->order_id . '</td><td><span class="label">Invoice</span></td><td>' . $r->invoice . '</td></tr>');
                echo('<tr><td><span class="label">Customer ID</span></td><td>' . $r->customer_id . '</td><td><span class="label">Purchase Order</span></td><td>' . $r->purchase_order . '</td></tr>');
                echo('<tr><td><span class="label">Transaction Type</span></td><td>' . $r->transaction_type . '</td><td><span class="label">Amount</span></td><td>' . $r->amount . '</td></tr>');
                echo('<tr><td><span class="label">Card</span></td><td>' . $r->card . '</td><td><span class="label">Card Expire Date</span></td><td>' . $r->exp_date . '</td></tr>');
                echo('<tr><td><span class="label">Result</span></td><td>' . $r->result . '</td><td><span class="label">Result Code</span></td><td>' . $r->result_code . '</td></tr>');
                echo('<tr><td><span class="label">Transaction ID</span></td><td>' . $r->transaction_id . '</td><td><span class="label">Exchange ID</span></td><td>' . $r->exchange_id . '</td></tr>');
                echo('<tr><td><span class="label">Authorization Code</span></td><td>' . $r->authorization_code . '</td><td><span class="label">Email Address</span></td><td>' . $r->email_address . '</td></tr>');
                echo('<tr><td><span class="label">Description</span></td><td>' . $r->description . '</td><td><span class="label">Comments</span></td><td>' . $r->comments . '</td></tr>');
                echo('<tr><td><span class="label">Billing Address</span></td><td>'
                    . $r->billing_firstname . ' '
                    . $r->billing_lastname . '<br>'
                    . $r->billing_company . '<br>'
                    . $r->billing_street . '<br>'
                    . $r->billing_street2 . '<br>'
                    . $r->billing_city . ', ' . $r->billing_state . '&nbsp;&nbsp;' . $r->billing_zip . '<br>'
                    . $r->billing_country . '<br>'
                    . $r->billing_phone
                    . '</td><td><span class="label">Shipping Address</span></td><td>'
                    . $r->shipping_firstname . ' '
                    . $r->shipping_lastname . '<br>'
                    . $r->shipping_company . '<br>'
                    . $r->shipping_street . '<br>'
                    . $r->shipping_street2 . '<br>'
                    . $r->shipping_city . ', ' . $r->shipping_state . '&nbsp;&nbsp;' . $r->shipping_zip . '<br>'
                    . $r->shipping_country . '<br>'
                    . $r->shipping_phone
                    . '</td>');
                echo('<tr><td><span class="label">Date Added</span></td><td>' . $r->date_added . '</td><td><span class="label">Date Modified</span></td><td>' . $r->date_modified . '</td></tr>');
                echo('<tr><td><span class="label">Client IP</span></td><td>' . $r->client_ip . '</td><td><span class="label">User Agent</span></td><td>' . $r->user_agent . '</td></tr>');
            }
            echo('</table>');
        }

    }

    public function clearent_pay_form($atts, $content, $tag) {
        //@session_start();


        // set up directories
        $plugins_url = plugins_url();
        $get_admin_url = get_admin_url();

        $trans_path = $plugins_url . "/clearent-payments/clearent/transaction.php";
        $js_path = $plugins_url . "/clearent-payments/js/";
        $css_path = $plugins_url . "/clearent-payments/css/";
        $image_path = $plugins_url . "/clearent-payments/image/";

        wp_enqueue_script('jquery-ui-autocomplete');
        wp_enqueue_style('jquery-ui', $css_path . 'jquery-ui.min.css');


        // get shortcode options
        $a = $this->parse_form_options($atts);
        // get year dropdown options
        $year_options = $this->clearent_util->get_year_options();

        $form = '';

        $amount = $a['amount'];
        if ($amount == 0) {
            $form .= 'Payment amount is missing; please contact website administrator.';
            return $form;
        } else {
            $amount = number_format((float)$amount, 2, '.', '');
        }

        $_SESSION["amount"] = $amount;
        $_SESSION["require-csc"] = (is_bool($a['require-csc']) && $a['require-csc'] != false);
        $_SESSION["require-billing-address"] = (is_bool($a['require-billing-address']) && $a['require-billing-address'] != false);
        $_SESSION["require-shipping-address"] = (is_bool($a['require-shipping-address']) && $a['require-shipping-address'] != false);
        $_SESSION["atts"] = $a;
        $this->clearent_util->logger("--------------------- begin SESSION['atts'] ---------------------");
        $this->clearent_util->logger($_SESSION["atts"]);
        $this->clearent_util->logger("--------------------- end SESSION['atts'] ---------------------");

        $trans_url = $get_admin_url . 'admin-post.php';
        $form .= '<script type="text/javascript" src="' . $js_path . 'clearent.js" ></script>';
        $form .= '<script type="text/javascript" src="' . $js_path . 'loading.js" ></script>';
        $form .= '<link type="text/css" rel="stylesheet" href="' . $css_path . 'clearent.css" />';
        $form .= '<link type="text/css" rel="stylesheet" href="' . $css_path . 'loading.css" />';
        $form .= '<script type="text/javascript">
                    var  trans_url =  "' . $trans_url . '"
                  </script>
                  <div class="wp_clearent_button">
                    <h3>' . $a['title'] . '</h3>
                    <div id="errors" class="hidden clearent-warning"><span id="errors_message"></span></div>
                    <form action="' . $get_admin_url . 'admin-post.php" method="POST" class="clearent-payment-form" autocomplete="off">
                      <div class="clearent-card-acceptance">
                          <img class="acceptedCards" src="' . $image_path . 'clearent-cards.png">
                      </div>
                      <span class="clearent_required_note">* indicates required field</span>
                      <input style="display: none;" type="text" autocomplete="foo" />
                      <table class="clearent-table">
                        <tbody>
                          <tr>
                            <td>
                              <label for="card">* ' . $a['card-label'] . '</label>
                            </td>
                            <td>
                              <input type="text" id="card" name="card" value="" maxlength="27" />
                            </td>
                          </tr>
                          <tr>
                            <td>
                              <label for="expire-date-month">* ' . $a['exp-date-label'] . '</label>
                            </td>
                            <td>
                              <select name="expire-date-month" id="expire-date-month" class="clearent-select-field">
                                <option value="01">January</option>
                                <option value="02">February</option>
                                <option value="03">March</option>
                                <option value="04">April</option>
                                <option value="05">May</option>
                                <option value="06">June</option>
                                <option value="07">July</option>
                                <option value="08">August</option>
                                <option value="09">September</option>
                                <option value="10">October</option>
                                <option value="11">November</option>
                                <option value="12">December</option>
                              </select>
                              /
                              <select name="expire-date-year" id="expire-date-year" class="clearent-select-field">
                              ' . $year_options . '
                              </select>
                            </td>
                          </tr>
                          <tr>
                            <td>
                              <label for="csc">' . ((is_bool($a['require-csc']) && $a['require-csc'] != false) ? '* ' : '&nbsp;&nbsp; ') . $a['csc-label'] . '</label>
                            </td>
                            <td>
                              <input type="text" id="csc" name="csc" value="" />
                            </td>
                          </tr>';

        /* optional field - show if set to true in shortcode - hidden if value set in short code - not present if set to false in shortcode or not set  */
        if (is_bool($a['invoice']) && $a['invoice'] != false) {
            $form .= '<tr>
                        <td><label for="invoice">' . $a['invoice-label'] . '</label></td>
                        <td>
                          <input type="text" id="invoice" name="invoice" value="" />
                        </td>
                      </tr>';
        } else if (!is_bool($a['invoice']) && isset($a['invoice'])) {
            $form .= '<input type="hidden" id="invoice" name="invoice" value="' . ($a['invoice']) . '" />';
        }

        /* optional field - show if set to true in shortcode - hidden if value set in short code - not present if set to false in shortcode or not set  */
        if (is_bool($a['purchase-order']) && $a['purchase-order'] != false) {
            $form .= '<tr>
                        <td><label for="purchase-order">' . $a['purchase-order-label'] . '</label></td>
                        <td>
                          <input type="text" id="purchase-order" name="purchase-order" value="" />
                        </td>
                      </tr>';
        } else if (!is_bool($a['purchase-order']) && isset($a['purchase-order'])) {
            $form .= '<input type="hidden" id="purchase-order" name="purchase-order" value="' . ($a['purchase-order'] == 'true' ? "" : $a['purchase-order']) . '" />';
        }

        /* optional field - show if set to true in shortcode - hidden if value set in short code - not present if set to false in shortcode or not set  */
        if (is_bool($a['email-address']) && $a['email-address'] != false) {
            $form .= '<tr>
                        <td><label for="email-address">' . $a['email-address-label'] . '</label></td>
                        <td>
                          <input type="text" id="email-address" name="email-address" value="" />
                        </td>
                      </tr>';
        } else if (!is_bool($a['email-address']) && isset($a['email-address'])) {
            $form .= '<input type="hidden" id="email-address" name="email-address" value="' . ($a['email-address'] == 'true' ? "" : $a['email-address']) . '" />';
        }

        /* optional field - show if set to true in shortcode - hidden if value set in short code - not present if set to false in shortcode or not set  */
        if (is_bool($a['customer-id']) && $a['customer-id'] != false) {
            $form .= '<tr>
                        <td><label for="customer-id">' . $a['customer-id-label'] . '</label></td>
                        <td>
                          <input type="text" id="customer-id" name="customer-id" value="" />
                        </td>
                      </tr>';
        } else if (!is_bool($a['customer-id']) && isset($a['customer-id'])) {
            $form .= '<input type="hidden" id="customer-id" name="customer-id" value="' . ($a['customer-id'] == 'true' ? "" : $a['customer-id']) . '" />';
        }

        /* optional field - show if set to true in shortcode - hidden if value set in short code - not present if set to false in shortcode or not set  */
        if (is_bool($a['order-id']) && $a['order-id'] != false) {
            $form .= '<tr>
                        <td><label for="order-id">' . $a['order-id-label'] . '</label></td>
                        <td>
                          <input type="text" id="order-id" name="order-id" value="" />
                        </td>
                      </tr>';
        } else if (!is_bool($a['order-id']) && isset($a['order-id'])) {
            $form .= '<input type="hidden" id="order-id" name="order-id" value="' . ($a['order-id'] == 'true' ? "" : $a['order-id']) . '" />';
        }

        /* optional field - show if set to true in shortcode - hidden if value set in short code - not present if set to false in shortcode or not set  */
        if (is_bool($a['description']) && $a['description'] != false) {
            $form .= '<tr>
                        <td><label for="description">' . $a['description-label'] . '</label></td>
                        <td>
                          <input type="text" id="description" name="description" value="" />
                        </td>
                      </tr>';
        } else if (!is_bool($a['description']) && isset($a['description'])) {
            $form .= '<input type="hidden" id="description" name="description" value="' . ($a['description'] == 'true' ? "" : $a['description']) . '" />';
        }

        /* optional field - show if set to true in shortcode - hidden if value set in short code - not present if set to false in shortcode or not set  */
        if (is_bool($a['comments']) && $a['comments'] != false) {
            $form .= '<tr>
                        <td><label for="comments">' . $a['comments-label'] . '</label></td>
                        <td>
                          <input type="text" id="comments" name="comments" value="" />
                        </td>
                      </tr>';
        } else if (!is_bool($a['comments']) && isset($a['comments'])) {
            $form .= '<input type="hidden" id="comments" name="comments" value="' . ($a['comments'] == 'true' ? "" : $a['comments']) . '" />';
        }

        if ((is_bool($a['billing-address']) && $a['billing-address'] != false) || (is_bool($a['require-billing-address']) && $a['require-billing-address'] != false)) {
            $form .= '
                          <tr>
                            <td class="clearent-table-heading">' . ((is_bool($a['require-billing-address']) && $a['require-billing-address'] != false) ? '* ' : '') . $a['billing-address-label'] . '</td>
                            <td></td>
                          </tr>
                          <tr>
                            <td><label class="clearent-address-label" for="billing-first-name">' . $a['billing-first-name-label'] . '</label></td>
                            <td>
                              <input type="text" id="billing-first-name" name="billing-first-name" value="" />
                            </td>
                          </tr>
                          <tr>
                            <td><label class="clearent-address-label" for="billing-last-name">' . $a['billing-last-name-label'] . '</label></td>
                            <td>
                              <input type="text" id="billing-last-name" name="billing-last-name" value="" />
                            </td>
                          </tr>
                          <tr>
                            <td><label class="clearent-address-label" for="billing-company">' . $a['billing-company-label'] . '</label></td>
                            <td>
                              <input type="text" id="billing-company" name="billing-company" value="" />
                            </td>
                          </tr>
                          <tr>
                            <td><label class="clearent-address-label" for="billing-street">' . $a['billing-street-label'] . '</label></td>
                            <td>
                              <input type="text" id="billing-street" name="billing-street" value="" />
                            </td>
                          </tr>
                          <tr>
                            <td><label class="clearent-address-label" for="billing-street2">' . $a['billing-street2-label'] . '</label></td>
                            <td>
                              <input type="text" id="billing-street2" name="billing-street2" value="" />
                            </td>
                          </tr>
                          <tr>
                            <td><label class="clearent-address-label" for="billing-city">' . $a['billing-city-label'] . '</label></td>
                            <td>
                              <input type="text" name="billing-city" id="billing-city" value="" />
                            </td>
                          </tr>
                          <tr>
                            <td><label class="clearent-address-label" for="billing-state">' . $a['billing-state-label'] . '</label></td>
                            <td>
                              <input autocomplete="off" type="text" name="billing-state" id="billing-state" />
                            </td>
                          </tr>
                          <tr>
                            <td><label class="clearent-address-label" for="billing-zip">' . $a['billing-zip-label'] . '</label></td>
                            <td>
                              <input type="text" name="billing-zip" id="billing-zip" value="" />
                            </td>
                          </tr>
                          <tr>
                            <td><label class="clearent-address-label" for="billing-country">' . $a['billing-country-label'] . '</label></td>
                            <td>
                              <input type="text" name="billing-country" id="billing-country" value="" />
                            </td>
                          </tr>
                          <tr>
                            <td><label class="clearent-address-label" for="billing-phone">' . $a['billing-phone-label'] . '</label></td>
                            <td>
                              <input type="text" name="billing-phone" id="billing-phone" value="" />
                            </td>
                          </tr>
                          ';
        }

        if ((is_bool($a['shipping-address']) && $a['shipping-address'] != false) || (is_bool($a['require-shipping-address']) && $a['require-shipping-address'] != false)) {
            $form .= '
                          <tr>
                            <td class="clearent-table-heading">' . ((is_bool($a['require-shipping-address']) && $a['require-shipping-address'] != false) ? '* ' : '') . $a['shipping-address-label'] . '</td>
                            <td>'
                .
                (((is_bool($a['billing-address']) && $a['billing-address'] != false) || (is_bool($a['require-billing-address']) && $a['require-billing-address'] != false)) ? '<input type="checkbox" name="billing-is-shipping" id="billing-is-shipping" value="true"  />&nbsp;<label class="clearent-inline-label" for="billing-is-shipping">' . $a['billing-is-shipping-label'] . '</label>' : '')
                .
                '</td>
                          </tr>
                          <tr>
                            <td><label class="clearent-address-label" for="shipping-first-name">' . $a['shipping-first-name-label'] . '</label></td>
                            <td>
                              <input type="text" id="shipping-first-name" name="shipping-first-name" value="" />
                            </td>
                          </tr>
                          <tr>
                            <td><label class="clearent-address-label" for="shipping-last-name">' . $a['shipping-last-name-label'] . '</label></td>
                            <td>
                              <input type="text" id="shipping-last-name" name="shipping-last-name" value="" />
                            </td>
                          </tr>
                          <tr>
                            <td><label class="clearent-address-label" for="shipping-company">' . $a['shipping-company-label'] . '</label></td>
                            <td>
                              <input type="text" id="shipping-company" name="shipping-company" value="" />
                            </td>
                          </tr>
                          <tr>
                            <td><label class="clearent-address-label" for="shipping-street">' . $a['shipping-street-label'] . '</label></td>
                            <td>
                              <input type="text" name="shipping-street" id="shipping-street" value="" />
                            </td>
                          </tr>
                          <tr>
                            <td><label class="clearent-address-label" for="shipping-street2">' . $a['shipping-street2-label'] . '</label></td>
                            <td>
                              <input type="text" name="shipping-street2" id="shipping-street2" value="" />
                            </td>
                          </tr>
                          <tr>
                            <td><label class="clearent-address-label" for="shipping-city">' . $a['shipping-city-label'] . '</label></td>
                            <td>
                              <input type="text" name="shipping-city" id="shipping-city" value="" />
                            </td>
                          </tr>
                          <tr>
                            <td><label class="clearent-address-label" for="shipping-state">' . $a['shipping-state-label'] . '</label></td>
                            <td>
                              <input type="text" name="shipping-state" id="shipping-state" />
                            </td>
                          </tr>
                          <tr>
                            <td><label class="clearent-address-label" for="shipping-zip">' . $a['shipping-zip-label'] . '</label></td>
                            <td>
                              <input type="text" name="shipping-zip" id="shipping-zip" value="" />
                            </td>
                          </tr>
                          <tr>
                            <td><label class="clearent-address-label" for="shipping-country">' . $a['shipping-country-label'] . '</label></td>
                            <td>
                              <input type="text" name="shipping-country" id="shipping-country" value="" />
                            </td>
                          </tr>
                          <tr>
                            <td><label class="clearent-address-label" for="shipping-phone">' . $a['shipping-phone-label'] . '</label></td>
                            <td>
                              <input type="text" name="shipping-phone" id="shipping-phone" value="" />
                            </td>
                          </tr>
                          ';
        }

        $form .= '<tr>
                    <td></td>
                    <td>
                      <input type="button" class="submit_wp_clearent" id="wp_clearent_submit" name="wp_clearent_submit" value="' . $a['button-text'] . '" />
                    </td>
                  </tr>
                </tbody>
              </table>
              <div id="errors_message_bottom" class="hidden clearent-warning"><span>Please correct errors noted above.</span></div>
              <div class="clearent-security">
                <div class="clearent-lock" aria-hidden="true"></div>Secured by <a title="http://www.clearent.com/" href="http://www.clearent.com/" target="_blank"><div class="clearent-logo logo"></div></a>
              </div>
            </form>
          </div>';

        return $form;
    }

    public function parse_form_options($atts) {
        // get shortcode properties
        $atts = shortcode_atts(array(
            'amount' => 0,
            // labels
            'title' => 'Complete Transaction Details Below',
            'button_text' => 'Pay Now',
            'card_label' => 'Card Number',
            'exp_date_label' => 'Card Expiration Date',
            'csc_label' => 'Card Security Code',
            'invoice_label' => 'Invoice Number',
            'purchase_order_label' => 'Purchase Order',
            'email_address_label' => 'Email Address',
            'customer_id_label' => 'Customer ID',
            'order_id_label' => 'Order ID',
            'description_label' => 'Description',
            'comments_label' => 'Comments',
            'billing_address_label' => 'Billing Address',
            'billing_first_name_label' => 'First Name',
            'billing_last_name_label' => 'Last Name',
            'billing_company_label' => 'Company',
            'billing_street_label' => 'Address',
            'billing_street2_label' => 'Address Line 2',
            'billing_city_label' => 'City',
            'billing_state_label' => 'State',
            'billing_zip_label' => 'Zip',
            'billing_country_label' => 'Country',
            'billing_phone_label' => 'Phone',
            'shipping_address_label' => 'Shipping',
            'billing_is_shipping_label' => 'Same as billing address',
            'shipping_first_name_label' => 'First Name',
            'shipping_last_name_label' => 'Last Name',
            'shipping_company_label' => 'Company',
            'shipping_street_label' => 'Address',
            'shipping_street2_label' => 'Address Line 2',
            'shipping_city_label' => 'City',
            'shipping_state_label' => 'State',
            'shipping_zip_label' => 'Zip',
            'shipping_country_label' => 'Country',
            'shipping_phone_label' => 'Phone',
            // optional fields
            'invoice' => false,
            'purchase_order' => false,
            'email_address' => false,
            'customer_id' => false,
            'order_id' => false,
            'description' => false,
            'comments' => false,
            // shipping/billing
            'billing_address' => false,
            'shipping_address' => false,
            // field options
            'require_billing_address' => false,
            'require_shipping_address' => false,
            'require_csc' => true
        ), $atts);

        $a = array();

        foreach ($atts as $key => $value) {
            // wordpress before 4.3 does not support hypens in shortcode attribute names
            // our api uses hypens so to keep the internal code clean I am converting
            // shortcode underscores to hyphens in the resulting array
            //$key = str_replace ( "_" , "-", $key);

            $this->clearent_util->logger("BEFORE: " . $key . " = " . json_encode($value));

            $newKey = str_replace("_", "-", $key);

            if ($value === "true" || $value === true) {
                $newValue = true;
                $this->clearent_util->logger("converting to boolean: true");
            } elseif ($value === "false" || $value === false) {
                $newValue = false;
                $this->clearent_util->logger("converting to boolean: false");
            } else {
                $newValue = $value;
            }

            $a[$newKey] = $newValue;

            if ($newKey != $key || $newValue != $value) {
                $this->clearent_util->logger(" AFTER: " . $newKey . " = " . json_encode($newValue));
            }

        }

        return $a;
    }

    // [clearent_pay_button pk="2123ds13213213213213213132132" heading-text="Acme Widgets" amount="22.88"]
    public function clearent_pay_button($atts, $content, $tag) {

        if (get_option($this->option_name)['enable_debug'] == 'sandbox') {
            $url = wp_clearent::SANDBOX_HPP_URL;
        } else {
            $url = wp_clearent::PRODUCTION_HPP_URL;
        }
        $this->clearent_util->logger("HPP URL = " . $url);

        $s = '';
        $s .= '<script type="text/javascript" src="' . $url . '"></script>';
        $s .= "\n<script>\n";
        $s .= "Clearent.setProperty('pk','1234567890');\n";

        foreach ($atts as $key => $value) {

            switch ($value) {
                case is_null($value):
                    break;
                case strtolower($value) == 'true':
                case strtolower($value) == 'false':
                    $s .= "Clearent.setProperty('$key',$value);\n";
                    break;
                default:
                    $s .= "Clearent.setProperty('$key','$value');\n";
                    break;
            }

        }

        $s .= "Clearent.payButton();\n";

        // called after successful complete
        $s .= "function ClearentOnSuccess(responseRaw,ResponseJSON){\n";
        $s .= "    console.log(\"transaction successful\");\n";
        $s .= "    console.log(responseRaw);\n";
        $s .= "    console.log(ResponseJSON);\n";
        $s .= "}\n";

        // called after failed complete
        $s .= "function ClearentOnError(responseRaw,ResponseJSON){\n";
        $s .= "    console.log(\"transaction failed\");\n";
        $s .= "    console.log(responseRaw);\n";
        $s .= "    console.log(ResponseJSON);\n";
        $s .= "}\n";

        $s .= "</script>\n";

        return $s;
    }

    public function validate() {
        //session_start();

        $this->clearent_util->logger('validating transaction data');

        $has_errors = false;
        $response = array();
        $response['error'] = '';

        $atts = $_SESSION["atts"];
        $this->clearent_util->logger("--------------------- begin shortcode attributes ---------------------");
        $this->clearent_util->logger($atts);
        $this->clearent_util->logger("--------------------- end shortcode attributes ---------------------");

        // check Card
        if (!$_REQUEST['card']) {
            $message = "Card Number is required.";
            $this->clearent_util->logger($message);
            $response['error'] = $response['error'] . $message . '<br>';
            $has_errors = true;
        } else if (strlen(preg_replace("/[^0-9]/", "", $_REQUEST['card'])) < 13 || strlen(preg_replace("/[^0-9]/", "", $_REQUEST['card'])) > 19) {
            $message = "Card Number must be between 13 and 19 characters in length.";
            $this->clearent_util->logger($message);
            $response['error'] = $response['error'] . $message . '<br>';
            $has_errors = true;
        }

        // check Date
        $today = getdate();
        $selected_month = intval($_REQUEST['expire-date-month']);
        $current_month = $today['mon'];
        $selected_year = $_REQUEST['expire-date-year'];
        $current_year = strftime('%y', mktime(0, 0, 0, 1, 1, $today['year']));

        if ($selected_year < $current_year || ($selected_month < $current_month && $selected_year == $current_year)) {
            $message = "Card Expiration Date can not be in the past.";
            $this->clearent_util->logger($message);
            $this->clearent_util->logger("selected month/year = " . $selected_month . ' / ' . $selected_year);
            $this->clearent_util->logger("current month/year = " . $current_month . ' / ' . $current_year);
            $response['error'] = $response['error'] . $message . '<br>';
            $has_errors = true;
        }


        // check CSC
        if (is_bool($_SESSION["require-csc"]) && $_SESSION["require-csc"] != false) {
            // check for csc
            if (strlen($_REQUEST['csc']) == 0) {
                $message = "Card Security Code is required.";
                $this->clearent_util->logger($message);
                $response['error'] = $response['error'] . $message . '<br>';
                $has_errors = true;
            } else if (isset($_REQUEST['csc']) && !in_array(strlen($_REQUEST['csc']), [3, 4])) {
                // required - must be 3 or 4 characters
                $message = "Card Security Code must be 3 or 4 characters.";
                $this->clearent_util->logger($message);
                $response['error'] = $response['error'] . $message . '<br>';
                $has_errors = true;
            }
        } else if (isset($_REQUEST['csc']) && !in_array(strlen($_REQUEST['csc']), [0, 3, 4])) {
            // not required - must be 0, 3 or 4 characters
            $message = "Card Security Code must be 3 or 4 characters.";
            $this->clearent_util->logger($message);
            $response['error'] = $response['error'] . $message . '<br>';
            $has_errors = true;
        }

        // check billing address
        $require_billing_address = is_bool($_SESSION["require-billing-address"]) && $_SESSION["require-billing-address"] != false;
        $require_shipping_address = is_bool($_SESSION["require-shipping-address"]) && $_SESSION["require-shipping-address"] != false;
        // request params hit server as strings so we test for 'false' not false
        $billing_is_shipping = $_REQUEST['billing-is-shipping'] && $_REQUEST["billing-is-shipping"] != 'false';

        if ($require_billing_address || ($require_shipping_address && $billing_is_shipping)) {
            // require fields if(require-billing-address=true || (require-shipping-address=true && billing-is-shipping=true))
            if (!$_REQUEST['billing-first-name']) {
                $message = "Billing Address First Name is required.";
                $this->clearent_util->logger($message);
                $response['error'] = $response['error'] . $message . '<br>';
                $has_errors = true;
            }
            if (!$_REQUEST['billing-last-name']) {
                $message = "Billing Address Last Name is required.";
                $this->clearent_util->logger($message);
                $response['error'] = $response['error'] . $message . '<br>';
                $has_errors = true;
            }
            if (!$_REQUEST['billing-street']) {
                $message = "Billing Address Street is required.";
                $this->clearent_util->logger($message);
                $response['error'] = $response['error'] . $message . '<br>';
                $has_errors = true;
            }
            if (!$_REQUEST['billing-city']) {
                $message = "Billing Address City is required.";
                $this->clearent_util->logger($message);
                $response['error'] = $response['error'] . $message . '<br>';
                $has_errors = true;
            }
            if (!$_REQUEST['billing-state']) {
                $message = "Billing Address State is required.";
                $this->clearent_util->logger($message);
                $response['error'] = $response['error'] . $message . '<br>';
                $has_errors = true;
            }
            if (!$_REQUEST['billing-zip']) {
                $message = "Billing Address Zip is required.";
                $this->clearent_util->logger($message);
                $response['error'] = $response['error'] . $message . '<br>';
                $has_errors = true;
            }
            if (!$_REQUEST['billing-country']) {
                $message = "Billing Address Country is required.";
                $this->clearent_util->logger($message);
                $response['error'] = $response['error'] . $message . '<br>';
                $has_errors = true;
            }
            if (!$_REQUEST['billing-phone']) {
                $message = "Billing Address Phone is required.";
                $this->clearent_util->logger($message);
                $response['error'] = $response['error'] . $message . '<br>';
                $has_errors = true;
            }
        }

        // check shipping address
        if ($require_shipping_address && !$billing_is_shipping) {
            // require fields if(require-shipping-address=true && billing-is-shipping=false)
            if (!$_REQUEST['shipping-first-name']) {
                $message = "Shipping Address First Name is required.";
                $this->clearent_util->logger($message);
                $response['error'] = $response['error'] . $message . '<br>';
                $has_errors = true;
            }
            if (!$_REQUEST['shipping-last-name']) {
                $message = "Shipping Address Last Name is required.";
                $this->clearent_util->logger($message);
                $response['error'] = $response['error'] . $message . '<br>';
                $has_errors = true;
            }
            if (!$_REQUEST['shipping-street']) {
                $message = "Shipping Address Street is required.";
                $this->clearent_util->logger($message);
                $response['error'] = $response['error'] . $message . '<br>';
                $has_errors = true;
            }
            if (!$_REQUEST['shipping-city']) {
                $message = "Shipping Address City is required.";
                $this->clearent_util->logger($message);
                $response['error'] = $response['error'] . $message . '<br>';
                $has_errors = true;
            }
            if (!$_REQUEST['shipping-state']) {
                $message = "Shipping Address State is required.";
                $this->clearent_util->logger($message);
                $response['error'] = $response['error'] . $message . '<br>';
                $has_errors = true;
            }
            if (!$_REQUEST['shipping-zip']) {
                $message = "Shipping Address Zip is required.";
                $this->clearent_util->logger($message);
                $response['error'] = $response['error'] . $message . '<br>';
                $has_errors = true;
            }
            if (!$_REQUEST['shipping-country']) {
                $message = "Shipping Address Country is required.";
                $this->clearent_util->logger($message);
                $response['error'] = $response['error'] . $message . '<br>';
                $has_errors = true;
            }
            if (!$_REQUEST['shipping-phone']) {
                $message = "Shipping Address Phone is required.";
                $this->clearent_util->logger($message);
                $response['error'] = $response['error'] . $message . '<br>';
                $has_errors = true;
            }
        }

        if ($has_errors) {
            $this->clearent_util->logger("response=" . json_encode($response));
            echo json_encode($response);
        } else {
            $this->send();
        }

    }

    public function send() {
        //session_start();

        $this->clearent_util->logger('beginning send function');
        $options = get_option($this->option_name);

        $payment_data = array();
        if ($options['environment'] == "sandbox") {
            $this->clearent_util->logger('PLUGIN IS RUNNING IN SANDBOX MODE');
            $url = wp_clearent::SANDBOX_API_URL;
            $payment_data['api-key'] = $options['sb_api_key'];
        } else {
            $this->clearent_util->logger('PLUGIN IS RUNNING IN PRODUCTION MODE');
            $url = wp_clearent::PRODUCTION_API_URL;
            $payment_data['api-key'] = $options['prod_api_key'];
        }

        // transaction data
        $payment_data['type'] = 'SALE';
        $payment_data['software-type'] = 'wordpress';
        $payment_data['amount'] = $_SESSION["amount"];
        $payment_data['card'] = preg_replace("/[^0-9]/", "", $_REQUEST["card"]);
        $payment_data['exp-date'] = $_REQUEST["expire-date-month"] . $_REQUEST["expire-date-year"];
        $payment_data['csc'] = $_REQUEST["csc"];

        // transaction metadata
        $payment_data['invoice'] = $_REQUEST['invoice'];
        $payment_data['purchase-order'] = $_REQUEST['purchase-order'];
        $payment_data['email-address'] = $_REQUEST['email-address'];
        $payment_data['customer-id'] = $_REQUEST['customer-id'];
        $payment_data['order-id'] = $_REQUEST['order-id'];
        $payment_data['client-ip'] = $_SERVER['REMOTE_ADDR'];
        $payment_data['description'] = $_REQUEST['description'];
        $payment_data['comments'] = $_REQUEST['comments'];

        $billing = array(
            'first-name' => $_REQUEST['billing-first-name'],
            'last-name' => $_REQUEST['billing-last-name'],
            'company' => $_REQUEST['billing-company'],
            'street' => $_REQUEST['billing-street'],
            'street2' => $_REQUEST['billing-street2'],
            'city' => $_REQUEST['billing-city'],
            'state' => $_REQUEST['billing-state'],
            'zip' => $_REQUEST['billing-zip'],
            'country' => $_REQUEST['billing-country'],
            'phone' => $_REQUEST['billing-phone'],
        );
        $payment_data['billing'] = $billing;

        if (isset($_REQUEST['billing-is-shipping']) && $_REQUEST['billing-is-shipping'] == 'true') {
            $this->clearent_util->logger("HasShipping is false");
            $payment_data['billing-is-shipping'] = "true";
        } else {
            $this->clearent_util->logger("HasShipping is true");
            $payment_data['billing-is-shipping'] = "false";
            $shipping = array(
                'first-name' => $_REQUEST['shipping-first-name'],
                'last-name' => $_REQUEST['shipping-last-name'],
                'company' => $_REQUEST['shipping-company'],
                'street' => $_REQUEST['shipping-street'],
                'street2' => $_REQUEST['shipping-street2'],
                'city' => $_REQUEST['shipping-city'],
                'state' => $_REQUEST['shipping-state'],
                'zip' => $_REQUEST['shipping-zip'],
                'country' => $_REQUEST['shipping-country'],
                'phone' => $_REQUEST['shipping-phone'],
            );
            $payment_data['shipping'] = $shipping;
        }

        $this->clearent_util->logger("-------------------- begin payment_data --------------------");
        $this->clearent_util->logger($payment_data);
        $this->clearent_util->logger("--------------------- end payment_data ---------------------");

        $response_data = $this->clearent_util->sendCurl($url, $payment_data);
        $responseDataAsJSON = json_decode($response_data);

        $response = array();

        if ($responseDataAsJSON->{'code'} == '200') {

            // 1 - Put together a message that will show in the Order History area of the admin tool.
            $message = '';
            $message .= 'Message: ' . $responseDataAsJSON->payload->transaction->{'display-message'} . "\n";
            $message .= 'Exchange Id: ' . $responseDataAsJSON->{'exchange-id'} . "\n";
            $message .= 'Transaction Id: ' . $responseDataAsJSON->payload->transaction->id . "\n";
            $message .= 'Authorization Code: ' . $responseDataAsJSON->payload->transaction->{'authorization-code'} . "\n";
            $this->clearent_util->logger($message);

            // 2 - log order details in database
            $table_name = 'clearent_transaction';
            $today = current_time('mysql', 0);
            $id = date("YmdHis") . '_' . rand(1111111, 9999999);
            $values = array(
                'id' => $id,
                'transaction_type' => $payment_data['type'],
                'amount' => $payment_data['amount'],
                'card' => str_repeat('X', strlen($payment_data['card']) - 4) . substr($payment_data['card'], -4),
                'exp_date' => $payment_data['exp-date'],
                'invoice' => $payment_data['invoice'],
                'purchase_order' => $payment_data['purchase-order'],
                'email_address' => $payment_data['email-address'],
                'customer_id' => $payment_data['customer-id'],
                'order_id' => $payment_data['order-id'],
                'description' => $payment_data['description'],
                'comments' => $payment_data['comments'],
                'billing_firstname' => $payment_data['billing']['first-name'],
                'billing_lastname' => $payment_data['billing']['last-name'],
                'billing_company' => $payment_data['billing']['company'],
                'billing_street' => $payment_data['billing']['street'],
                'billing_street2' => $payment_data['billing']['street2'],
                'billing_city' => $payment_data['billing']['city'],
                'billing_state' => $payment_data['billing']['state'],
                'billing_zip' => $payment_data['billing']['zip'],
                'billing_country' => $payment_data['billing']['country'],
                'billing_phone' => $payment_data['billing']['phone'],
                'billing_is_shipping' => $payment_data['billing-is-shipping'],
                'shipping_firstname' => $payment_data['shipping']['first-name'],
                'shipping_lastname' => $payment_data['shipping']['last-name'],
                'shipping_company' => $payment_data['shipping']['company'],
                'shipping_street' => $payment_data['shipping']['street'],
                'shipping_street2' => $payment_data['shipping']['street2'],
                'shipping_city' => $payment_data['shipping']['city'],
                'shipping_state' => $payment_data['shipping']['state'],
                'shipping_zip' => $payment_data['shipping']['zip'],
                'shipping_country' => $payment_data['shipping']['country'],
                'shipping_phone' => $payment_data['shipping']['phone'],
                'client_ip' => $_SERVER['REMOTE_ADDR'],
                'message' => $message,
                'transaction_id' => $responseDataAsJSON->payload->transaction->id,
                'authorization_code' => $responseDataAsJSON->payload->transaction->{'authorization-code'},
                'exchange_id' => $responseDataAsJSON->{'exchange-id'},
                'result' => $responseDataAsJSON->payload->transaction->{'result'},
                'result_code' => $responseDataAsJSON->payload->transaction->{'result-code'},
                'response_raw' => $response_data,
                'user_agent' => $_SERVER['HTTP_USER_AGENT'],
                'date_added' => $today,
                'date_modified' => $today,
            );
            $this->clearent_wp_util->add_record($table_name, $values);

            // 3 - add success redirect url to response
            $success_url = $options['success_url'];
            if ($success_url == "-1") {
                $response['redirect'] = get_home_url();
            } else {
                $response['redirect'] = get_permalink($success_url);
            }

        } else {
            $message = '';
            if (isset($responseDataAsJSON->payload->transaction) && isset($responseDataAsJSON->payload->transaction->{'display-message'})) {
                $message .= 'Message: ' . $responseDataAsJSON->payload->transaction->{'display-message'} . "\n";
                $message .= 'Result Code: ' . $responseDataAsJSON->payload->transaction->{'result-code'} . "\n";
                $response['error'] = $responseDataAsJSON->payload->transaction->{'display-message'};
            } else {
                $message .= 'Message: ' . $responseDataAsJSON->payload->error->{'error-message'} . "\n";
                $message .= 'Result Code: ' . $responseDataAsJSON->payload->error->{'result-code'} . "\n";
                $response['error'] = $responseDataAsJSON->payload->error->{'error-message'};
            }
            $message .= 'ExchangeId: ' . $responseDataAsJSON->{'exchange-id'} . "\n";
            $this->clearent_util->logger($message);
            $this->clearent_util->logger('Response data: ' . $responseDataAsJSON->{'status'} . ': ' . $responseDataAsJSON->payload->error->{'error-message'});
        }

        echo json_encode($response);

    }

    // This function will populate the options if the plugin is activated for the first time.
    // It will also protect the options if the plugin is deactivated (common in troubleshooting WP related issues)
    // We may want to add an option to remove DB entries...
    public function activate() {

        $options = get_option($this->option_name);

        $options['environment'] = isset($options['environment']) ? $options['environment'] : 'sandbox';
        $options['success_url'] = isset($options['success_url']) ? $options['success_url'] : '-1';
        $options['sb_api_key'] = isset($options['sb_api_key']) ? $options['sb_api_key'] : '';
        $options['prod_api_key'] = isset($options['prod_api_key']) ? $options['prod_api_key'] : '';
        $options['enable_debug'] = isset($options['enable_debug']) ? $options['enable_debug'] : 'disabled';

        update_option($this->option_name, $options);

    }

    public function install_db() {
        global $wpdb;

        $table_name = $wpdb->prefix . "clearent_transaction";
        $charset_collate = $wpdb->get_charset_collate();

        // mysql char can hold up to 30 characters - switch to varchar if more is needed
        $sql = "CREATE TABLE $table_name (
            id CHAR(25) NOT NULL,
            transaction_type CHAR(15) NOT NULL,
            amount CHAR(10) NOT NULL,
            card CHAR(19) NOT NULL,
            exp_date CHAR(4) NOT NULL,
            invoice VARCHAR(32),
            purchase_order VARCHAR(32),
            email_address VARCHAR(96),
            customer_id  VARCHAR(32),
            order_id VARCHAR(32),
            description TEXT,
            comments TEXT,
            billing_firstname VARCHAR(32),
            billing_lastname VARCHAR(32),
            billing_company VARCHAR(32),
            billing_street VARCHAR(128),
            billing_street2 VARCHAR(128),
            billing_city VARCHAR(128),
            billing_state VARCHAR(40),
            billing_zip CHAR(10),
            billing_country VARCHAR(128),
            billing_phone VARCHAR(32),
            billing_is_shipping tinyint(1),
            shipping_firstname VARCHAR(32),
            shipping_lastname VARCHAR(32),
            shipping_company VARCHAR(32),
            shipping_street VARCHAR(128),
            shipping_street2 VARCHAR(128),
            shipping_city VARCHAR(128),
            shipping_state VARCHAR(40),
            shipping_zip CHAR(10),
            shipping_country VARCHAR(128),
            shipping_phone VARCHAR(32),
            client_ip VARCHAR(45),
            message TEXT,
            transaction_id CHAR(30),
            authorization_code VARCHAR(32),
            exchange_id VARCHAR(128),
            result VARCHAR(32),
            result_code CHAR(10),
            response_raw TEXT,
            user_agent VARCHAR(255),
            date_added DATETIME NOT NULL,
            date_modified DATETIME NOT NULL,
            PRIMARY KEY  (id)
        )  $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);

    }

}

$wp_clearent = new wp_clearent();
