=== Plugin Name ===
Contributors: clearent1
Tags: clearent, payments, credit card, ecommerce
Requires at least: 4.0
Tested up to: 4.3
Stable tag: /trunk/
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Clearent Payments v2. Contact Clearent at http://www.clearent.com for more information.

== Description ==

This plugin allows easy payments into your WordPress using Clearent's secure payment gateway. Contact Clearent at http://www.clearent.com for more information.

== Installation ==

This section describes how to install the plugin and get it working.

1. Unzip `wp-clearent.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Contact Clearent at http://www.clearent.com/merchants/contact-us/ to request sandbox api key for testing and production key for live sales.
4. Configure Success URL in plugin. This is the page that your users will be taken to after a successful transaction.
5. Add clearent_pay_form on your page to show payment form. Minimum required shortcode attribute is "amount".

Example basic shortcode for your page (amount field attribute is required):

[clearent_pay_form amount="41.77"]

Example shortcode with all payment field attributes:

[clearent_pay_form amount="88.20" billing_address=true shipping_address=true invoice=true purchase_order=true email_address=true customer_id=true order_id=true description=true comments=true ]

The following fields are known as configurable fields: invoice, purchase_order, email_address, customer_id, order_id, description, and comments.
- If these fields are set to false are not present, they are not displayed on the page.
- If these fields are set to true, they are displayed on the page for user input.
- If these fields are configured with values, they are saved with the transaction but are not displayed or editiable by the user.

Example shortcode with configured field attributes:

[clearent_pay_form require_csc="true" amount="21.50" invoice="ABN145-8" purchase_order="PN-4545" email_address="joe@smith.com" customer_id="js_1112" order_id="0102115" description="blue canoe" comments="rush order" require_billing_address=true require_shipping_address=true]

The table below summarizes the shortcode attributes available with this plugin.

<table border="1">
    <tr><th>Shortcode attribute</th><th>Default value</th><th>Notes</th><th></th></tr>
    <tr><td>amount </td><td>0</td><td>Value is required</td><td></td></tr>
    <tr><th>// labels</th><th>Default value</th><th>Notes</th><th></th></tr>
    <tr><td>title </td><td>�Complete Transaction Details Below</td><td></td><td></td></tr>
    <tr><td>button_text </td><td>�Pay Now</td><td></td><td></td></tr>
    <tr><td>card_label </td><td>�Card Number</td><td></td><td></td></tr>
    <tr><td>exp_date_label </td><td>�Card Expiration Date</td><td></td><td></td></tr>
    <tr><td>csc_label </td><td>�Card Security Code</td><td></td><td></td></tr>
    <tr><td>invoice_label </td><td>�Invoice Number</td><td></td><td></td></tr>
    <tr><td>purchase_order_label </td><td>�Purchase Order</td><td></td><td></td></tr>
    <tr><td>email_address_label </td><td>�Email Address</td><td></td><td></td></tr>
    <tr><td>customer_id_label </td><td>�Customer ID</td><td></td><td></td></tr>
    <tr><td>order_id_label </td><td>�Order ID</td><td></td><td></td></tr>
    <tr><td>description_label </td><td>�Description</td><td></td><td></td></tr>
    <tr><td>comments_label </td><td>�Comments</td><td></td><td></td></tr>
    <tr><td>billing_address_label </td><td>�Billing Address</td><td>Only applicable if billing fields are shown</td><td></td></tr>
    <tr><td>billing_first_name_label </td><td>�First Name</td><td></td><td></td></tr>
    <tr><td>billing_last_name_label </td><td>�Last Name</td><td></td><td></td></tr>
    <tr><td>billing_company_label </td><td>�Company</td><td></td><td></td></tr>
    <tr><td>billing_street_label </td><td>�Address</td><td></td><td></td></tr>
    <tr><td>billing_street2_label </td><td>�Address Line 2</td><td></td><td></td></tr>
    <tr><td>billing_city_label </td><td>�City</td><td></td><td></td></tr>
    <tr><td>billing_state_label </td><td>�State</td><td></td><td></td></tr>
    <tr><td>billing_zip_label </td><td>�Zip</td><td></td><td></td></tr>
    <tr><td>billing_country_label </td><td>�Country</td><td></td><td></td></tr>
    <tr><td>billing_phone_label </td><td>�Phone</td><td></td><td></td></tr>
    <tr><td>shipping_address_label </td><td>�Shipping</td><td>Only applicable if shipping fields are shown</td><td></td></tr>
    <tr><td>billing_is_shipping_label </td><td>�Same as billing address</td><td></td><td></td></tr>
    <tr><td>shipping_first_name_label </td><td>�First Name</td><td></td><td></td></tr>
    <tr><td>shipping_last_name_label </td><td>�Last Name</td><td></td><td></td></tr>
    <tr><td>shipping_company_label </td><td>�Company</td><td></td><td></td></tr>
    <tr><td>shipping_street_label </td><td>�Address</td><td></td><td></td></tr>
    <tr><td>shipping_street2_label </td><td>�Address Line 2</td><td></td><td></td></tr>
    <tr><td>shipping_city_label </td><td>�City</td><td></td><td></td></tr>
    <tr><td>shipping_state_label </td><td>�State</td><td></td><td></td></tr>
    <tr><td>shipping_zip_label </td><td>�Zip</td><td></td><td></td></tr>
    <tr><td>shipping_country_label </td><td>�Country</td><td></td><td></td></tr>
    <tr><td>shipping_phone_label </td><td>�Phone</td><td></td><td></td></tr>
    <tr><th>// optional fields</th><th>Default value</th><th>Notes</th><th></th></tr>
    <tr><td>invoice </td><td>�false</td><td>If "true", field is shown</td><td></td></tr>
    <tr><td>purchase_order </td><td>�false</td><td>If "false", field is not shown</td><td></td></tr>
    <tr><td>email_address </td><td>�false</td><td>If any other value, field is hidden with value set</td><td></td></tr>
    <tr><td>customer_id </td><td>�false</td><td></td><td></td></tr>
    <tr><td>order_id </td><td>�false</td><td></td><td></td></tr>
    <tr><td>description </td><td>�false</td><td></td><td></td></tr>
    <tr><td>comments </td><td>�false</td><td></td><td></td></tr>
    <tr><th>// shipping/billing</th><th>Default value</th><th>Notes</th><th></th></tr>
    <tr><td>billing_address </td><td>�false</td><td>"true" to show all billing address fields (not needed if require_billing_address=true)</td><td></td></tr>
    <tr><td>shipping_address </td><td>�false</td><td>"true" to show all shipping address fields (not needed if require_shipping_address=true)</td><td></td></tr>
    <tr><th>// field options</th><th>Default value</th><th>Notes</th><th></th></tr>
    <tr><td>require_billing_address </td><td>�false</td><td>"true" to show and require billing address fields</td><td></td></tr>
    <tr><td>require_shipping_address </td><td>�false</td><td>"true" to show and require shipping address fields</td><td></td></tr>
    <tr><td>require_csc </td><td>�true</td><td></td><td></td></tr>
    <tr><th>// optional fields</th><th>Default value</th><th>billing_address=true</th><th>require_billing_address=true</th></tr>
    <tr><td>billing-first-name</td><td>Not displayed</td><td>Displayed</td><td>Displayed and required</td></tr>
    <tr><td>billing-last-name</td><td>Not displayed</td><td>Displayed</td><td>Displayed and required</td></tr>
    <tr><td>billing-company</td><td>Not displayed</td><td>Displayed</td><td>Displayed</td></tr>
    <tr><td>billing-street</td><td>Not displayed</td><td>Displayed</td><td>Displayed and required</td></tr>
    <tr><td>billing-street2</td><td>Not displayed</td><td>Displayed</td><td>Displayed</td></tr>
    <tr><td>billing-city</td><td>Not displayed</td><td>Displayed</td><td>Displayed and required</td></tr>
    <tr><td>billing-state</td><td>Not displayed</td><td>Displayed</td><td>Displayed and required</td></tr>
    <tr><td>billing-zip</td><td>Not displayed</td><td>Displayed</td><td>Displayed and required</td></tr>
    <tr><td>billing-country</td><td>Not displayed</td><td>Displayed</td><td>Displayed and required</td></tr>
    <tr><td>billing-phone</td><td>Not displayed</td><td>Displayed</td><td>Displayed and required</td></tr>
    <tr><th>// optional fields</th><th>Default value</th><th>shipping_address=true</th><th>require_shipping_address=true</th></tr>
    <tr><td>shipping-first-name</td><td>Not displayed</td><td>Displayed</td><td>Displayed and required</td></tr>
    <tr><td>shipping-last-name</td><td>Not displayed</td><td>Displayed</td><td>Displayed and required</td></tr>
    <tr><td>shipping-company</td><td>Not displayed</td><td>Displayed</td><td>Displayed</td></tr>
    <tr><td>shipping-street</td><td>Not displayed</td><td>Displayed</td><td>Displayed and required</td></tr>
    <tr><td>shipping-street2</td><td>Not displayed</td><td>Displayed</td><td>Displayed</td></tr>
    <tr><td>shipping-city</td><td>Not displayed</td><td>Displayed</td><td>Displayed and required</td></tr>
    <tr><td>shipping-state</td><td>Not displayed</td><td>Displayed</td><td>Displayed and required</td></tr>
    <tr><td>shipping-zip</td><td>Not displayed</td><td>Displayed</td><td>Displayed and required</td></tr>
    <tr><td>shipping-country</td><td>Not displayed</td><td>Displayed</td><td>Displayed and required</td></tr>
    <tr><td>shipping-phone</td><td>Not displayed</td><td>Displayed</td><td>Displayed and required</td></tr>
</table>

== Changelog ==

= 2.0 =
* Initial release using Clearent Payment Gateway v2
