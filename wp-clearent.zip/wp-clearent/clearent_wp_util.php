<?php

class clearent_wp_util {

    public function add_record($table_name,$values){
        global $wpdb;

        $table = $wpdb->prefix . $table_name;
        $wpdb->insert($table,$values);

    }



}

